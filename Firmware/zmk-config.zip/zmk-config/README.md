# VectorSplitK — ZMK Config

Custom ZMK shield for the VectorSplitK, targeting the `seeeduino_xiao_ble` board (Seeed Studio XIAO nRF52840).

## Layout

- 5 columns × 5 rows per half, 21 keys/side (20 in a 4×5 grid + 1 thumb key), 42 keys total.
- `diode-direction = "col2row"`, matching the D_SOD-123 orientation on the PCB.

## Pin mapping (from schematic, identical on both halves)

| Signal | XIAO Pin |
|---|---|
| COL_0 | P0.03 |
| COL_1 | P0.28 |
| COL_2 | P0.29 |
| COL_3 | P0.04 |
| COL_4 | P0.05 |
| ROW_0 | P1.15 |
| ROW_1 | P1.14 |
| ROW_2 | P1.13 |
| ROW_3 | P1.12 |
| ROW_4 | P1.11 |

## ⚠️ Before you flash

The `matrix-transform` in `vectorsplitk.dtsi` assumes **COL_0 is the innermost column** (closest to the thumb key / center gap) on both halves. This was not fully confirmed against the PCB silkscreen. If your first test shows keys typing in mirrored/reversed order left-to-right, just reverse the column order in each row of the `map` in `vectorsplitk.dtsi` — no rewiring needed, it's a firmware-only fix.

## Build

Push this repo to GitHub with the folder structure below; `build.yaml` + `.github/workflows/build.yml` will auto-build both `.uf2` files via ZMK's GitHub Actions pipeline. Grab them from the Actions tab under Artifacts.

```
zmk-config/
├── build.yaml
├── config/
│   ├── vectorsplitk.keymap
│   ├── vectorsplitk.conf
│   └── west.yml
├── boards/shields/vectorsplitk/
│   ├── vectorsplitk.dtsi
│   ├── vectorsplitk_left.overlay
│   ├── vectorsplitk_right.overlay
│   ├── vectorsplitk.zmk.yml
│   ├── Kconfig.shield
│   └── Kconfig.defconfig
└── .github/workflows/build.yml
```

## Flash

1. Double-tap Reset on the XIAO to mount it as a USB drive.
2. Drag the matching `.uf2` (left/right) onto the drive.
